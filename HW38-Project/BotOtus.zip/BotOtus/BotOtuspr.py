﻿from imaplib import Commands
import telebot
import pyodbc
import pandas as pd
conn = pyodbc.connect("Driver={SQL Server};"
                      "Server=DESKTOP-0P3RUG1\SQL2022;UID=test;PWD=test1"
                      "Database=Project_otus_telegram;"
                      "Trusted_Connection=yes;")



cursor = conn.cursor()


#sql = ('INSERT INTO [Project_otus_telegram].[dbo].[botUsers] ([name] , [name_i], [email] ) VALUES (?,?,?)')
#val = ('Иванов', 'Иван', 'ivanov@gmail.com')
#cursor.execute(sql, val)
#conn.commit()
#cursor.execute('SELECT [id_users] ,[name] ,[email] FROM [Project_otus_telegram].[dbo].[botUsers]')
#for row in cursor:
#    print('row = %r' % (row,))
bot = telebot.TeleBot("7061849613:AAFk1EPK2dsmF9o4168dPTfrYLcBxyqRuUs", parse_mode=None)
user_dict = {}
class User:
    def __init__(self, first_name):
        self.first_name = first_name
        self.last_name = ''
        self.email = ''
        self.firm_id = 1
        self.sex = None

@bot.message_handler(commands=['start'])
def send_welcom(message):
    sql = ('SELECT count(*) FROM [Project_otus_telegram].[dbo].[botUsers] where [user_id_tg] = ?')
    val = (message.from_user.id)
    cursor.execute(sql, val)
    result = cursor.fetchone()
    while result:
    
        if result[0]==1:
            mess = f'Добрый день, <b>{message.from_user.first_name}</b>. Чем я могу Вам помочь?'
            msg = bot.send_message(message.chat.id, mess, parse_mode='html')
            #bot.register_next_step_handler(msg, process_firstname_step)
        else:   
            mess = f'Добрый день, <b>{message.from_user.first_name}</b>. Для начала зарегистрируйтесь.'
            msg = bot.send_message(message.chat.id, mess, parse_mode='html')
            bot.register_next_step_handler(msg, process_firstname_step)
            
        break
    
def process_firstname_step(message):
    try:
        user_id = message.from_user.id
        user_dict[user_id] = User(message.text)
        
        mess = f'<b>{message.from_user.first_name}</b>, введите фамилию.'
        msg = bot.send_message(message.chat.id, mess, parse_mode='html')
        bot.register_next_step_handler(msg, process_lastname_step)
    except Exception as e:
        bot.reply_to(message, 'Что-то пошло не так. Попробуйте еще раз.')
def process_lastname_step(message):
    try:
        user_id = message.from_user.id
        user = user_dict[user_id]
        user.last_name = message.text
         
        mess = f' <b>{message.from_user.first_name}</b>, введите адрес эл. почты.'
        msg = bot.send_message(message.chat.id, mess, parse_mode='html')
        bot.register_next_step_handler(msg, process_email_step)
    except Exception as e:
        bot.reply_to(message, 'Что-то пошло не так. Попробуйте еще раз.')
def process_email_step(message):
    try:
        user_id = message.from_user.id
        user = user_dict[user_id]
        user.email = message.text
        err = 0
        sql = ('exec [Project_otus_telegram].[dbo].[tech_add_user] ?,?,?,?,?,? out')
        val = (user.email, user.last_name, user.first_name, user_id, user.firm_id, err)
        cursor.execute(sql, val)
        cursor.commit()
        #val = (user.email, user.last_name, user.first_name, user_id, user.firm_id, (0, 'INT'))
        #result = cursor.callproc('[Project_otus_telegram].[dbo].[tech_add_user]', val)
        mess = f'Вы успешно зарегистрированы, <b>{message.from_user.first_name}</b>.'
        msg = bot.send_message(message.chat.id, mess, parse_mode='html')
 
    except Exception as e:
        bot.reply_to(message, 'Что-то пошло не так. Попробуйте еще раз.')   
        
@bot.message_handler(commands=['command1'])
def send_welcom(message):
    mess = f'<b>{message.from_user.first_name}</b>, Ваша заявка принята. Обработка займет некоторое время.'
    msg = bot.send_message(message.chat.id, mess, parse_mode='html')
    sql = ('SELECT count(*) FROM [Project_otus_telegram].[dbo].[botUsers] where [user_id_tg] = ?')
    val = (message.from_user.id)
    cursor.execute(sql, val)
    result = cursor.fetchone()
    while result:
    
        if result[0]==1:
            mess = f'Добрый день, <b>{message.from_user.first_name}</b>. Чем я могу Вам помочь?'
            msg = bot.send_message(message.chat.id, mess, parse_mode='html')
            #bot.register_next_step_handler(msg, process_firstname_step)
        else:   
            mess = f'Добрый день, <b>{message.from_user.first_name}</b>. Для начала зарегистрируйтесь.'
            msg = bot.send_message(message.chat.id, mess, parse_mode='html')
            bot.register_next_step_handler(msg, process_firstname_step)
            
        break
#@bot.message_handler()
#def get_user_text(message):
#    if message.text == 'Привет':
#        bot.send_message(message.chat.id, 'И тебе привет!', parse_mode='html') 
#    else:
#         bot.send_message(message.chat.id, 'Я тебя не понимаю!', parse_mode='html')
# Enable saving next step handlers to file "./.handlers-saves/step.save".
# Delay=2 means that after any change in next step handlers (e.g. calling register_next_step_handler())
# saving will hapen after delay 2 seconds.
bot.enable_save_next_step_handlers(delay=2)

# Load next_step_handlers from save file (default "./.handlers-saves/step.save")
# WARNING It will work only if enable_save_next_step_handlers was called!
bot.load_next_step_handlers()         
if __name__ == '__main__':
  bot.polling(non_stop = True)



    